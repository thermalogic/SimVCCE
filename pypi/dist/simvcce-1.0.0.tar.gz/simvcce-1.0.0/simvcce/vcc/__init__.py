"""
 General Object-oriented Abstraction of VC Cycle 
"""

import sys
sys.path.append('../')
